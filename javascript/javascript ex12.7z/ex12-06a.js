const mt = document.querySelector("#mytext") ?? "요소없음";
console.log(mt);
mt.innerHTML = `<h2><mark>너무반갑죠!</mark></h2>`;
function fn (...arr){ // 나머지 매개변수
    console.log(...arr) // 전개연산자
}
fn(1,2,3,4,5,6)